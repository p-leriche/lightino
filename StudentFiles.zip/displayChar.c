void displayChar(char ch){
  if (ch < 32 || ch > 126){
    ch = 32;
    }
  // subtract the space character (converts the ASCII number to the font index number)
  ch -= 32;
  // step through each byte of the character array
  for (int i=0; i<charWidth; i++) {
    char b = pgm_read_byte_near(&(font[ch][i]));
    
    for (int j=0; j<charHeight; j++) {
      digitalWrite(led_anodes[j], bitRead(b, j));
    }
    dwellDelay(1);
  }
  
  //clear the LEDs
  for (int i = 0; i < rows; i++)
    digitalWrite(led_anodes[i] , LOW);
  dwellDelay(1);
}

void displayCharLower(char ch){
  // make sure the character is within the alphabet bounds (defined by the font.h file)
  // if it's not, make it a blank character
  if (ch < 32 || ch > 126){
    ch = 32;
    }
  // subtract the space character (converts the ASCII number to the font index number)
  ch -= 32;
  // step through each byte of the character array
  for (int i=charWidth-1; i>-1; i--) {
    char b = pgm_read_byte_near(&(font[ch][i]));
    for (int j=0; j<charHeight; j++) {
      digitalWrite(led_anodes[j+1], bitRead(b,charHeight - 1 - j));
    }
    dwellDelay(1);
  }
  //clear the LEDs
  for (int i = 0; i < rows; i++)
    digitalWrite(led_anodes[i] , LOW);

  // space between letters
  dwellDelay(1);
}